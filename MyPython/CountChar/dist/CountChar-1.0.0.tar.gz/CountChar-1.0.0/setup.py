from distutils.core import setup
setup(
	name="CountChar",
	version="1.0.0",
	py_modules=["CountChar"],
	author="Guo.yang",
	author_email="gyang973256@gmail.com",
	url="https://github.com/holyTornado",
	description="统计指定文件文件里指定字符出现的次数！",
)
