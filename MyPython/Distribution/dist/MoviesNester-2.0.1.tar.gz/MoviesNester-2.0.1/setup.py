from distutils.core import setup
setup(
	name="MoviesNester",
	version="2.0.1",
	py_modules=["MoviesNester"],
	author="Guo.yang",
	author_email="gyang973256@gmail.com",
	url="https://github.com/holyTornado",
	description="A simple printer of nested lists."
				"此次修改改正了保存到文件功能",
)
