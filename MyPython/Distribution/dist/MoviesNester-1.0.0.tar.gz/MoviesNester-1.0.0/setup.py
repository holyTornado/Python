from distutils.core import setup
setup(
	name="MoviesNester",
	version="1.0.0",
	py_modules=["MoviesNester"],
	author="Guo.yang",
	author_email="holy_e@163.com",
	url="http://www.google.com",
	description="A simple printer of nested lists.",
)
