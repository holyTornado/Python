from distutils.core import setup
setup(
	name="MoviesNester",
	version="2.0.0",
	py_modules=["MoviesNester"],
	author="Guo.yang",
	author_email="gyang973256@gmail.com",
	url="https://github.com/holyTornado",
	description="A simple printer of nested lists.",
)
